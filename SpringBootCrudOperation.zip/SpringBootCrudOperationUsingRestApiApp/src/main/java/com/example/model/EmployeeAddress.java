package com.example.model;

import java.util.ArrayList;
import java.util.Collection;

import javax.persistence.Entity;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "EMPLOYEEADDRESS_TBL")
public class EmployeeAddress {
	
	private long id;
	private Address address;
	private Employee employee;
	private String addressType;
	@ManyToMany(mappedBy = "employeeaddresses", targetEntity=Employee.class)
	private Collection<Employee> employees = new ArrayList<Employee>();
	
}
