package com.example.model;

import java.time.LocalDate;
import java.util.Collection;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "EMPLOYEE_TBL")
public class Employee {
	
	@Id
	@GeneratedValue
	private long id;
	private String name;
	private LocalDate dateOfBirth;
	@ManyToMany (targetEntity=Address.class)
	@JoinTable(name = "EMPLOYEE_EMPLOYEEADDRESS_ADDRESS",
	    joinColumns=@JoinColumn(name="EMPLOYEE_ID"),
	    inverseJoinColumns=@JoinColumn(name="ADDRESS_ID"))
	private Collection<Address> addresses;
	@ManyToMany (targetEntity=EmployeeAddress.class)
	@JoinTable(name="EMPLOYEE_EMPLOYEEADDRESS_ADDRESS",
	     joinColumns=@JoinColumn(name="EMPLOYEE_ID"),
	     inverseJoinColumns=@JoinColumn(name="EMPLOYEEADDRESS_ID"))
	private Collection<EmployeeAddress> employeeaddress;
	
}
