package com.example.model;

import java.util.ArrayList;
import java.util.Collection;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name= "ADDRESS_TBL")
public class Address {
	
	@Id
	@GeneratedValue
	private long id;
	private String addrLineOne;
	private String addrLineTwo;
	private String city;
	@ManyToMany(mappedBy="addresses", targetEntity=Employee.class)
	private Collection<Employee> employees = new ArrayList<Employee>();
 }

