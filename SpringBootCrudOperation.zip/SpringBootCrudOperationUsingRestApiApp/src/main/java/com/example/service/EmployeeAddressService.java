package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.model.Address;
import com.example.model.EmployeeAddress;
import com.example.repository.EmployeeAddressRepository;

@Service
public class EmployeeAddressService {
	
	@Autowired
	private EmployeeAddressRepository repository;
	
	public EmployeeAddress saveEmployeeAddress(EmployeeAddress employeeaddress) {
		return repository.save(employeeaddress);
	}
	public List<EmployeeAddress> saveEmployeeAddress(List<EmployeeAddress> employeeaddress) {
		return repository.saveAll(employeeaddress);
	} 
	public List<EmployeeAddress> getEmployeeAddresses(){
		return repository.findAll();
		
	}
	public EmployeeAddress getEmployeeAddressById(long id){
		return repository.findById(id).orElse(null);
   }
	public String deleteEmployeeAddress(long id) {
		repository.deleteById(id);
		return "employeeaddress removed !! "+id;
	}
	public EmployeeAddress updateEmployeeAddress(EmployeeAddress employeeaddress) {
		EmployeeAddress existingEmployeeAddress = repository.findById(employeeaddress.getId()).orElse(null);
		existingEmployeeAddress.setAddress(employeeaddress.getAddress());
		existingEmployeeAddress.setEmployee(employeeaddress.getEmployee());
		existingEmployeeAddress.setAddressType(employeeaddress.getAddressType());
		return existingEmployeeAddress;
	}
}
