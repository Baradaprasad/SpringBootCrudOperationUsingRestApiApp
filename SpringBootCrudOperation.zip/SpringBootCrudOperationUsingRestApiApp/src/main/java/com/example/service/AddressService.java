package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.model.Address;
import com.example.repository.AddressRepository;

@Service
public class AddressService {
	
	@Autowired
	private AddressRepository repository;
	
	public Address saveAddress(Address address) {
		return repository.save(address);	
	}
	public List<Address> saveAddress(List<Address> addresses) {
		return repository.saveAll(addresses);
	}
	public List<Address> getAddresses(){
		return repository.findAll();
		
	}
	public Address getAddressById(long id){
		return repository.findById(id).orElse(null);
   }
	public String deleteAddress(long id) {
		repository.deleteById(id);
		return "address removed !! "+id;
	}
	public Address updateAddress(Address address) {
		Address existingAddress = repository.findById(address.getId()).orElse(null);
		existingAddress.setAddrLineOne(address.getAddrLineOne());
		existingAddress.setAddrLineTwo(address.getAddrLineTwo());
		existingAddress.setCity(address.getCity());
		return repository.save(existingAddress);
	}

}
