package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.model.EmployeeAddress;
import com.example.service.EmployeeAddressService;

@RestController
public class EmployeeAddressController {
	
	@Autowired
	private EmployeeAddressService service;
	
	// create EmployeeAddress
	@PostMapping("/createEmployeeAddress")
	public EmployeeAddress createEmployeeAddress(@RequestBody EmployeeAddress employeeaddress) {
		return service.saveEmployeeAddress(employeeaddress);
	}
	// create EmployeeAddresses
	@PostMapping("/createEmployeeAddresses")
	public List<EmployeeAddress> createEmployeeAddresses(@RequestBody List<EmployeeAddress> employeeaddresses) {
		return service.saveEmployeeAddress(employeeaddresses);
	}
	// create Get all EmployeeAddresses
	@GetMapping("/EmployeeAddresses")
	public List<EmployeeAddress> findAllEmployeeAddresses(){
		return service.getEmployeeAddresses();
	}
	// Get EmployeeAddress By Id
	@GetMapping("/EmployeeAddress/{id}")
	public EmployeeAddress findEmployeeAddressById(@PathVariable long id) {
		return service.getEmployeeAddressById(id);
	}
	// Update EmployeeAddress
	@PutMapping("/update")
	public EmployeeAddress updateEmployeeAddress(@RequestBody EmployeeAddress employeeaddress) {
		return service.updateEmployeeAddress(employeeaddress);
	}
	// Delete EmployeeAddress
	@DeleteMapping("/delete/{id}")
	public String deleteEmployeeAddress(@PathVariable long id) {
		return service.deleteEmployeeAddress(id);
	}
}
