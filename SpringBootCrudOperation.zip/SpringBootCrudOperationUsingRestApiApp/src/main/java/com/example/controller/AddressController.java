package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.model.Address;
import com.example.service.AddressService;

@RestController
public class AddressController {
	
	@Autowired
	private AddressService service;
	
	// create Address
	@PostMapping("/createAddress")
	public Address createAddress(@RequestBody Address address) {
		return service.saveAddress(address);
	}
	// create Addresses
	@PostMapping("/createAddresses")
	public List<Address> createAddresses(@RequestBody List<Address> addresses) {
		return service.saveAddress(addresses);
	}
	// create get all Addresses
	@GetMapping("/Addresses")
	public List<Address> findAllAddresses(){
		return service.getAddresses();
	}
	// Get Address By Id
	@GetMapping("/Address/{id}")
	public Address findAddressById(@PathVariable long id) {
		return service.getAddressById(id);
	}
	// Update Address
	@PutMapping("/update")
	public Address updateAddress(@RequestBody Address address) {
		return service.updateAddress(address);
	}
	// Delete Address
	@DeleteMapping("/delete/{id}")
	public String deleteAddress(@PathVariable long id) {
		return service.deleteAddress(id);
	}
}
